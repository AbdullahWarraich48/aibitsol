<?php
/**
 * Temporary shim: reuse the Blogs Custom Marketing layout/content
 * for the Blog landing page so the PHP site matches the React version.
 */
include __DIR__ . '/blogs-custom-marketing.php';


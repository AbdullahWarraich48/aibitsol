<?php
/**
 * Temporary: reuse the Mobile Apps blog content until the custom software blog is ready.
 */
include __DIR__ . '/blogs-mobile-app.php';

<?php
/**
 * This route mirrors the Next.js “Blogs-Web-Design” page.
 * Reuse the generated markup from blogs-web-design.php so both URLs stay in sync.
 */
include __DIR__ . '/blogs-web-design.php';


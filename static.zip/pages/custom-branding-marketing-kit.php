<?php
/**
 * Temporary shim: reuse the Blogs Custom Marketing layout/content
 * for the Custom Branding & Marketing Kit page so both experiences match.
 */
include __DIR__ . '/blogs-custom-marketing.php';


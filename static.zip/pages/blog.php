<?php
/**
 * Temporary shim: reuse the Web Design blog content until the standalone
 * blog landing page is ready in PHP.
 */
include __DIR__ . '/blogs-web-design.php';


<?php
/**
 * Web Design blog route – reuse the full export so both URLs stay in sync.
 */
include __DIR__ . '/blogs-web-design-full.php';
